/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;


/**
 *
 * @author Bastien
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private Button btnConnect;
    @FXML
    private TextField userID;
    @FXML
    private TextField bddID;
    @FXML
    private PasswordField pswID;

    @FXML
    void display(ActionEvent event) {
        if (event.getSource() == btnConnect) {
            System.out.println("CLICKED");
            System.out.println("user ID : " + userID.getText());
            System.out.println("bdd ID : " + bddID.getText());
            System.out.println("psw ID : " + pswID.getText());

        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO        
    }

}
