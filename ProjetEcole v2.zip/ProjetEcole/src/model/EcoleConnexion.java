/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.*;

/**
 *
 * @author Java
 */
public class EcoleConnexion {

    private static String preurl = "jdbc:mysql://localhost:3306/";

    private static Connection connect;
    private Statement stmt;
    private ResultSet rset;
    private ResultSetMetaData rsetMeta;

    private EcoleConnexion(String _url, String _user, String _mdp) throws SQLException {
        try {
            connect = DriverManager.getConnection(_url, _user, _mdp);
            stmt = connect.createStatement();
        } catch (SQLException e) {
           throw new SQLException();
        }
    }

    public static Connection getConnexion(String _url, String _user, String _mdp) throws SQLException {
        if (connect == null) {
            try {
                String newURL = preurl + _url;
                System.out.println("URL : " + newURL);
                System.out.println("USER : " + _user);
                System.out.println("PSW : " + _mdp);
                new EcoleConnexion(newURL, _user, _mdp);
            } catch(SQLException e) {
                throw new SQLException();
            }
        }
        return connect;
    }

}
