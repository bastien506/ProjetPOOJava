/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 *
 * @author Bastien
 */
public class ConnexionGUI extends Application {

    Stage myStage = new Stage();

    @Override
    public void start(Stage stage) throws Exception {

        myStage = stage;
        Parent root = FXMLLoader.load(getClass().getResource("/fxml/Connexion.fxml"));

        Scene scene = new Scene(root);

        stage.addEventFilter(MouseEvent.MOUSE_PRESSED, e -> {
            if (e.isSecondaryButtonDown()) {
                stage.close();
            }

        });
        stage.setFullScreen(true);

        myStage.setScene(scene);
        myStage.show();
    }

    public void closeFrame() {

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
