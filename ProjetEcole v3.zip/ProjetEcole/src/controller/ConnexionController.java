/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.event.KeyEvent;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;
import javafx.stage.Window;
import model.FactoryDAO;

import view.MainMenuGUI;

/**
 *
 * @author Bastien
 */
public class ConnexionController implements Initializable {

    @FXML
    private Button btnConnect;
    @FXML
    private TextField userID;
    @FXML
    private TextField bddID;
    @FXML
    private PasswordField pswID;
    @FXML
    private TextFlow textflowID;

    @FXML
    void display(ActionEvent event) throws Exception {

        if (event.getSource() == btnConnect) {
            System.out.println("CLICKED");
            System.out.println("user ID : " + userID.getText());
            System.out.println("bdd ID : " + bddID.getText());
            System.out.println("psw ID : " + pswID.getText());

            try {
                FactoryDAO.tryConnectionBDD(bddID.getText(), userID.getText(), pswID.getText());

                Scene myCurrentScene = btnConnect.getScene();
                Window window = myCurrentScene.getWindow();
                Stage myCurrentStage = (Stage) window;

                textflowID.setVisible(false);
 
                MainMenuGUI menu = new MainMenuGUI();
                menu.start(myCurrentStage);
            } catch (SQLException e) {
                System.out.println("SQL exception caught");
                textflowID.setVisible(true);
            }

        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO      
    }

}
