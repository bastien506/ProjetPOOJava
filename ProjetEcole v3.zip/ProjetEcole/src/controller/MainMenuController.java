/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.Window;
import view.MenuMAJGUI;
import view.RechercheGUI;
import view.ReportingGUI;

/**
 * FXML Controller class
 *
 * @author Bastien
 */
public class MainMenuController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private Button btnMAJ;
    @FXML
    private Button btnReporting;
    @FXML
    private Button btnRecherche;
    @FXML
    private ImageView btnRetour;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO

    }

    @FXML
    void display(ActionEvent event) throws Exception {
        if (event.getSource() == btnMAJ) {
            System.out.println("MAJ");
            Scene myCurrentScene = btnMAJ.getScene();
            Window window = myCurrentScene.getWindow();
            Stage myCurrentStage = (Stage) window;

            MenuMAJGUI menu = new MenuMAJGUI();
            menu.start(myCurrentStage);

        } else if (event.getSource() == btnReporting) {
            System.out.println("Reporting");
            Scene myCurrentScene = btnReporting.getScene();
            Window window = myCurrentScene.getWindow();
            Stage myCurrentStage = (Stage) window;

            ReportingGUI menu = new ReportingGUI();
            menu.start(myCurrentStage);
        } else if (event.getSource() == btnRecherche) {
            System.out.println("Rchch");
            Scene myCurrentScene = btnRecherche.getScene();
            Window window = myCurrentScene.getWindow();
            Stage myCurrentStage = (Stage) window;

            RechercheGUI menu = new RechercheGUI();
            menu.start(myCurrentStage);
        }
    }

    @FXML
    private void retour(MouseEvent event) {
        if (event.getSource() == btnRetour) {
            System.out.println("Clicked");
        }
    }

}
