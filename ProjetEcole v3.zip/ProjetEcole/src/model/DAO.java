/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.*;
/**
 *
 * @author Java
 */
public abstract class DAO<D> {

    protected Connection connect = null;
    protected boolean hasNext;

    public DAO(Connection conn) {
        this.connect = conn;
    }

    public abstract boolean ajouter(D objet);

    public abstract boolean supprimer(D objet);

    public abstract boolean modifier(D objet);

    public abstract D trouver(int ID);
    
    public abstract boolean getNext();

}
