package model;

import java.util.ArrayList;

public class Ecole {

    private int ID;
    private String Nom;
    private int nbreElevesTot;
    private int nbreProfesseursTot;
    private int nbreClassesTot;
    private final ArrayList<Etudiant> collectionEtudiant = new ArrayList<>();
    private final ArrayList<Enseignant> collectionEnseignant = new ArrayList<>();
    private final ArrayList<Discipline> collectionDiscipline = new ArrayList<>();
    private final ArrayList<Niveau> collectionNiveau = new ArrayList<>();

    public Ecole() {

    }

    public void addCollectionEtudiant(Etudiant e) {
        collectionEtudiant.add(e);
    }

    public ArrayList<Etudiant> getCollectionEtudiant() {
        return this.collectionEtudiant;
    }

    public void addCollectionEnseignant(Enseignant e) {
        collectionEnseignant.add(e);
    }

    public ArrayList<Enseignant> getCollectionEnseignant() {
        return this.collectionEnseignant;
    }

    public void addCollectionDiscipline(Discipline e) {
        collectionDiscipline.add(e);
    }

    public ArrayList<Discipline> getCollectionDiscipline() {
        return this.collectionDiscipline;
    }

    public void addCollectionNiveau(Niveau e) {
        collectionNiveau.add(e);
    }

    public ArrayList<Niveau> getCollectionNiveau() {
        return this.collectionNiveau;
    }
    
    public void getDataFromBDD() {
        this.getEtudiantFromBDD();;
        this.getEnseignantFromBDD();
        this.getNiveauFromBDD();
        this.getDisciplineFromBDD();
    }

    public void getEtudiantFromBDD() {
        //Etudiant SQL
        DAO<Etudiant> myEtudiantDAO = FactoryDAO.getEtudiantDAO();
        int counter = 1;
        do {
            Etudiant myEtudiant = myEtudiantDAO.trouver(counter);
            counter++;
            if (myEtudiant.getID() != 0) {
                collectionEtudiant.add(myEtudiant);
            }
        } while (myEtudiantDAO.getNext());
    }

    public void getEnseignantFromBDD() {
        //Enseignant SQL
        DAO<Enseignant> myEnseignantDAO = FactoryDAO.getEnseignantDAO();
        int counter = 1;
        do {
            Enseignant myEnseignant = myEnseignantDAO.trouver(counter);
            counter++;
            if (myEnseignant.getID() != 0) {
                this.collectionEnseignant.add(myEnseignant);
            }
        } while (myEnseignantDAO.getNext());
    }

    public void getDisciplineFromBDD() {
        //Discipline SQL
        DAO<Discipline> myDisciplineDAO = FactoryDAO.getDisciplineDAO();
        int counter = 1;
        do {
            Discipline myDiscipline = myDisciplineDAO.trouver(counter);
            counter++;
            if (myDiscipline.getID() != 0) {
                this.collectionDiscipline.add(myDiscipline);
            }
        } while (myDisciplineDAO.getNext());
    }

    public void getNiveauFromBDD() {
        //Niveau SQL
        DAO<Niveau> myNiveauDAO = FactoryDAO.getNiveauDAO();
        int counter = 1;
        do {
            Niveau myNiveau = myNiveauDAO.trouver(counter);
            counter++;
            if (myNiveau.getID() != 0) {
                this.collectionNiveau.add(myNiveau);
            }
        } while (myNiveauDAO.getNext());
    }

    public void displayEcoleData() {
        System.out.println("\nMES ETUDIANTS :");
        for (int i = 0; i < this.collectionEtudiant.size(); i++) {
            System.out.println(this.collectionEtudiant.get(i).getID() + " - " + this.collectionEtudiant.get(i).getNom() + " " + this.collectionEtudiant.get(i).getPrenom());
        }

        System.out.println("\nMES PROFESSEURS :");
        for (int i = 0; i < this.collectionEnseignant.size(); i++) {
            System.out.println(this.collectionEnseignant.get(i).getID() + " - " + this.collectionEnseignant.get(i).getNom() + " " + this.collectionEnseignant.get(i).getPrenom());
        }

        System.out.println("\nMES DISCIPLINES :");
        for (int i = 0; i < this.collectionDiscipline.size(); i++) {
            System.out.println(this.collectionDiscipline.get(i).getID() + " - " + this.collectionDiscipline.get(i).getTheme());
        }

        System.out.println("\nMES NIVEAUX :");
        for (int i = 0; i < this.collectionNiveau.size(); i++) {
            System.out.println(this.collectionNiveau.get(i).getID() + " - " + this.collectionNiveau.get(i).getNom());
        }
    }
}
