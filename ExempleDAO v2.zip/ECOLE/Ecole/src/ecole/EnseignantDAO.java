/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecole;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Bastien
 */
public class EnseignantDAO extends DAO<Enseignant> {

    public EnseignantDAO(Connection conn) {
        super(conn);
        super.hasNext = true;
    }

    @Override
    public boolean ajouter(Enseignant objet) {
        return false;
    }

    @Override
    public boolean supprimer(Enseignant objet) {
        return false;
    }

    @Override
    public boolean modifier(Enseignant objet) {
        return false;
    }

    @Override
    public boolean getNext() {
        return super.hasNext;
    }

    @Override
    public Enseignant trouver(int ID) {

        int pre_ID = 12000;
        int newID = pre_ID + ID;
        Enseignant obj = new Enseignant();
        int ID_enseignant = 0;
        String Nom = "";
        String Prenom = "";

        try {
            Statement stmt = connect.createStatement();
            ResultSet RS;
            RS = stmt.executeQuery("SELECT * FROM enseignant WHERE ID_enseignant = " + newID);
            if (RS.next()) {
                ID_enseignant = RS.getInt("ID_enseignant");
                Nom = RS.getString("Nom");
                Prenom = RS.getString("Prenom");
                if (ID_enseignant != 0) {
                    obj = new Enseignant(ID_enseignant, Nom, Prenom);
                }
            } else {

                super.hasNext = false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return obj;
    }

}
