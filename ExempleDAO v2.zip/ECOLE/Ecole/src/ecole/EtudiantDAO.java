/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecole;

import java.sql.*;

/**
 *
 * @author Bastien
 */
public class EtudiantDAO extends DAO<Etudiant> {

    public EtudiantDAO(Connection conn) {
        super(conn);
        super.hasNext = true;
    }

    @Override
    public boolean ajouter(Etudiant objet) {
        return false;
    }

    @Override
    public boolean supprimer(Etudiant objet) {
        return false;
    }

    @Override
    public boolean modifier(Etudiant objet) {
        return false;
    }

    @Override
    public Etudiant trouver(int ID) {

        int pre_ID = 13000;
        int newID = pre_ID + ID;
        Etudiant obj = new Etudiant();
        int ID_etudiant = 0;
        String Nom = "";
        String Prenom = "";

        try {
            Statement stmt = connect.createStatement();
            ResultSet RS;
            RS = stmt.executeQuery("SELECT * FROM etudiant WHERE ID_etudiant = " + newID);
            if (RS.next()) {
                ID_etudiant = RS.getInt("ID_etudiant");
                Nom = RS.getString("Nom");
                Prenom = RS.getString("Prenom");
                if (ID_etudiant != 0) {
                    obj = new Etudiant(ID_etudiant, Nom, Prenom);
                }
            } else {

                super.hasNext = false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return obj;
    }

    @Override
    public boolean getNext() {
        return super.hasNext;
    }

}
