/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecole;

import java.sql.Connection;
import connexion.EcoleConnexion;
import java.util.ArrayList;

/**
 *
 * @author Bastien
 */
public class FactoryDAO {

    protected static final Connection conn = EcoleConnexion.getConnexion();

    /**
     * Retourne un objet Eleve interagissant avec la BDD
     *
     * @return DAO
     */
    public static DAO getEtudiantDAO() {
        return new EtudiantDAO(conn);
    }

    /**
     * Retourne un objet Professeur interagissant avec la BDD
     *
     * @return DAO
     */
    public static DAO getEnseignantDAO() {
        return new EnseignantDAO(conn);
    }

    /**
     * Retourne un objet Discipline interagissant avec la BDD
     *
     * @return DAO
     */
    public static DAO getDisciplineDAO() {
        return new DisciplineDAO(conn);
    }

    /**
     * Retourne un objet Niveau interagissant avec la BDD
     *
     * @return DAO
     */
    public static DAO getNiveauDAO() {
        return new NiveauDAO(conn);
    }

}
