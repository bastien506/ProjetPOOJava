/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecole;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Bastien
 */
public class NiveauDAO extends DAO<Niveau> {
     public NiveauDAO(Connection conn)  {
        super(conn);
        super.hasNext = true;
    }

    @Override
    public boolean ajouter(Niveau objet) {
        return false;
    }

    @Override
    public boolean supprimer(Niveau objet) {
        return false;
    }

    @Override
    public boolean modifier(Niveau objet) {
        return false;
    }

    @Override
    public boolean getNext() {
        return super.hasNext;
    }

    @Override
    public Niveau trouver(int ID) {

        int pre_ID = 9000;
        int newID = pre_ID + ID;
        Niveau obj = new Niveau();
        int ID_niveau = 0;
        String Nom = "";

        try {
            Statement stmt = connect.createStatement();
            ResultSet RS;
            RS = stmt.executeQuery("SELECT * FROM niveau WHERE ID_niveau = " + newID);
            if (RS.next()) {
                ID_niveau = RS.getInt("ID_niveau");
                Nom = RS.getString("Nom");
                if (ID_niveau != 0) {
                    obj = new Niveau(ID_niveau, Nom);
                }
            } else {

                super.hasNext = false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return obj;
    }
}
