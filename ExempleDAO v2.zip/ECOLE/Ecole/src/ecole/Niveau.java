/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecole;

/**
 *
 * @author Bastien
 */
public class Niveau {

    private int ID;
    private String nom;

    public Niveau(int _ID, String _nom) {
        this.ID = _ID;
        this.nom = _nom;
    }

    public Niveau() {

    }

    public int getID() {
        return this.ID;
    }

    public String getNom() {
        return this.nom;
    }
}
