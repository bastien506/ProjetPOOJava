/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecole;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Bastien
 */
public class DisciplineDAO extends DAO<Discipline> {

    public DisciplineDAO(Connection conn) {
        super(conn);
        super.hasNext = true;
    }

    @Override
    public boolean ajouter(Discipline objet) {
        return false;
    }

    @Override
    public boolean supprimer(Discipline objet) {
        return false;
    }

    @Override
    public boolean modifier(Discipline objet) {
        return false;
    }

    @Override
    public boolean getNext() {
        return super.hasNext;
    }

    @Override
    public Discipline trouver(int ID) {

        int pre_ID = 5000;
        int newID = pre_ID + ID;
        Discipline obj = new Discipline();
        int ID_discipline = 0;
        String Theme = "";

        try {
            Statement stmt = connect.createStatement();
            ResultSet RS;
            RS = stmt.executeQuery("SELECT * FROM discipline WHERE ID_discipline = " + newID);
            if (RS.next()) {
                ID_discipline = RS.getInt("ID_discipline");
                Theme = RS.getString("Nom");
                if (ID_discipline != 0) {
                    obj = new Discipline(ID_discipline, Theme);
                }
            } else {

                super.hasNext = false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return obj;
    }
}
