/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecole;

import java.sql.Connection;
import connexion.EcoleConnexion;
import java.util.ArrayList;

/**
 *
 * @author Bastien
 */
public class FactoryDAO {

    protected static final Connection conn = EcoleConnexion.getConnexion();
    private final ArrayList<Etudiant> collectionEtudiant = new ArrayList<>();

    /**
     * Retourne un objet Eleve interagissant avec la BDD
     *
     * @return DAO
     */
    public static DAO getEtudiantDAO() {
        return new EtudiantDAO(conn);
    }

    public void addCollectionEtudiant(Etudiant e) {
        collectionEtudiant.add(e);
    }

    public ArrayList<Etudiant> getCollectionEtudiant() {
        return this.collectionEtudiant;
    }
}
