/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecole;

/**
 *
 * @author Bastien
 */
public class Etudiant {

    private int ID;
    private String nom;
    private String prenom;
     
    Etudiant(int _ID, String _nom, String _prenom) {
        this.ID = _ID;
        this.nom = _nom;
        this.prenom = _prenom;
    }

    Etudiant() {
       
    }

    public int getID() {
        return this.ID;
    }

    public String getNom() {
        return this.nom;
    }

    public String getPrenom() {
       return this.prenom;
    }
    
}
