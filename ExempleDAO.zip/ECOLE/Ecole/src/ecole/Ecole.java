package ecole;

public class Ecole {

    public static void main(String[] args) {

        DAO<Etudiant> myEtudiantDAO = FactoryDAO.getEtudiantDAO();
        FactoryDAO myFactory = new FactoryDAO();
        int counter = 1;
        do {
            Etudiant myEtudiant = myEtudiantDAO.trouver(counter);
            counter++;
            if(myEtudiant.getID() != 0) {
                myFactory.addCollectionEtudiant(myEtudiant);
            }
        } while (myEtudiantDAO.getNext());

        for(int i = 0 ; i < myFactory.getCollectionEtudiant().size() ; i++) {
             System.out.println(myFactory.getCollectionEtudiant().get(i).getID() + "  - " + myFactory.getCollectionEtudiant().get(i).getNom() + " " + myFactory.getCollectionEtudiant().get(i).getPrenom());
        }
    }
}
