/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connexion;

import java.sql.*;

/**
 *
 * @author Java
 */
public class EcoleConnexion {

    private String url = "jdbc:mysql://localhost:3306/ecole";
    private String user = "root";
    private String mdp = "";

    private static Connection connect;
    private Statement stmt;
    private ResultSet rset;
    private ResultSetMetaData rsetMeta;

    private EcoleConnexion() {
        try {
            connect = DriverManager.getConnection(url, user, mdp);
            stmt = connect.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static Connection getConnexion() {
        if (connect == null) {
            new EcoleConnexion();
        }
        return connect;
    }

}
